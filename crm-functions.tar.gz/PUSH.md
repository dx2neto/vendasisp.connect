# Subir as functions no GitHub

O commit já está pronto (branch `main`, 13 arquivos). Escolha **um** caminho.

## Caminho A — repo novo só pras functions
```bash
# 1) baixe e descompacte o crm-functions.tar.gz, entre na pasta
cd crm-functions

# 2) crie o repo vazio no GitHub (site) e cole a URL abaixo
git init && git branch -m main
git add -A && git commit -m "feat: integrações IXCsoft + ZapSign"
git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
git push -u origin main
```

## Caminho B — usando o bundle (preserva o commit/histórico que já gerei)
```bash
# dentro do seu repositório já clonado:
git fetch /caminho/para/crm-functions.bundle main:functions-import
git checkout functions-import        # confere os arquivos
# mova/junte para a pasta certa (ex.: functions/) e faça merge na sua main
```

## Caminho C — eu subo por você (próximo turno)
Me diga **owner/repo** (ex.: `joao/crm-datacake`) e **autorize o conector do GitHub**
quando o app pedir. Aí eu faço o commit direto no repositório via API.
> Não cole token de acesso aqui no chat — prefira o conector ou rode os comandos acima.

## Onde colocar no repo
Em projetos Base44 as functions costumam ficar em `functions/` na raiz. Se o seu
repo segue esse padrão, coloque todos os `.js` (e o README) dentro de `functions/`.
