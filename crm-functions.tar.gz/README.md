# Integrações IXCsoft + ZapSign — Guia de instalação

Funções de backend (Deno) para o app Base44. Cada arquivo `.js` em `functions/` é uma
function que o frontend já chama via `base44.functions.invoke("nome", payload)`.
Os arquivos `ixcClient.js` e `zapsignClient.js` são módulos compartilhados (não são endpoints).

## 1. Secrets (Configurações do app > Secrets)

| Secret           | Exemplo                                   | Usado por                |
|------------------|-------------------------------------------|--------------------------|
| `IXC_HOST`       | `https://meuprovedor.ixc.com.br`          | todas as funções IXC     |
| `IXC_TOKEN`      | `28:0a1b2c...` (formato `id:hash`)         | todas as funções IXC     |
| `ZAPSIGN_TOKEN`  | token da API ZapSign                       | contratos                |
| `ZAPSIGN_BASE`   | (opcional) `https://sandbox.api.zapsign…` | usar sandbox em testes   |

O token do IXC é gerado no painel IXC e **já vem no formato `id:hash`** — o client faz o base64.

## 2. Funções públicas (sem login)

Marque como **públicas** no Base44 (são acessadas fora da área logada):

- `boletoFacil`     → página `/boleto`
- `assinarOnline`   → página `/assine`
- `webhookZapsign`  → chamada pelo servidor do ZapSign

As demais exigem usuário autenticado (admin/gerente/vendedor).

## 3. Webhook do ZapSign (assinatura em tempo real)

1. Pegue a URL pública da function `webhookZapsign` (Base44 mostra a URL do endpoint).
2. No ZapSign: **Configurações > Webhooks** → adicione a URL, evento **doc_signed**.
3. Quando o cliente assina, o Pedido vira `assinado` automaticamente e o botão
   **"Ativar Cliente no IXC"** aparece na esteira. Sem webhook, use o botão
   **"Sincronizar"** em `/contratos` (função `sincronizarContratos`, polling).

## 4. Campos de entidade usados

O código grava estes campos — confirme que existem nas entidades do app:

- **Pedido**: `sincronizado_ixc`, `id_cliente_ixc`, `id_contrato_ixc`, `id_os_ixc`,
  `link_assinatura`, `zapsign_token`, `contrato_id`, `data_ativacao`
- **Contrato**: `pedido_id`, `cliente_nome`, `status`, `link_assinatura`,
  `zapsign_token`, `template_id`, `conteudo`, `data_assinatura`
- **TemplateContrato**: `id_modelo_ixc`
- **Plano**: `id_modelo_ixc`, `id_produto_ixc`
- **ConfigRegras**: `id_filial_ixc`, `id_vendedor_ixc_padrao`, `id_assunto_os_ixc`,
  `id_setor_os_ixc`, `contribuinte_pf`, `status_contrato_inicial`

## 5. Pontos que variam por instância IXC (revisar)

O schema do IXC muda entre provedores. Confira principalmente:

- `cliente_contrato`: campos `id_modelo`, `status`, `status_internet`.
- `radgrupo` / `vd_produto`: nomes das tabelas de velocidade e produto em `sincronizarIXC`
  (caso sua instância use outras, ajuste `getPlanosERadius`).
- `su_oss_chamado`: `id_assunto`, `id_setor`, `tipo`, `status`.
- `get_pix` / `get_boleto`: alguns provedores usam endpoints/campos diferentes para 2ª via.

Cada função devolve o `detalhe`/`avisos` do IXC quando algo não confirma, pra facilitar o ajuste.

## 6. Ordem de teste sugerida

1. `testarIXC` (Configurações > IXC > Testar Conexão) e `testarZapSign` (Contratos).
2. `sincronizarIXC` (Configurações > Sincronizar) — puxa filiais/vendedores/OS/planos.
3. Vincule filial, vendedor, assunto/setor de OS e mapeie os planos ao IXC.
4. Em um pedido: **Enviar Contrato (ZapSign)** → assinar → **Ativar Cliente no IXC**.
