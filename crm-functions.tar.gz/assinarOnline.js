// functions/assinarOnline.js
// Fluxo público de assinatura online (página /assine -> Assinatura.jsx).
// Marque esta function como PÚBLICA no Base44.
//
// Entrada: { endereco, plano_info, dados, template_id, vendedor_id }
//   endereco   -> { tipo_acesso, nome, email, telefone, cep, endereco, numero, bairro, cidade, uf }
//   plano_info -> { plano: { id, nome, velocidade_mbps, preco_mensal }, total }
//   dados      -> { cpf, rg, data_nascimento, end_instalacao_*, fidelidade, vencimento, ... }
//
// Saída (lida pela Assinatura.jsx):
//   { link_assinatura } -> mostra o iframe de assinatura inline
//   {} ou { done:true } -> sem ZapSign/template: vai direto pra tela de confirmação

import { createClientFromRequest } from "npm:@base44/sdk";
import {
  zapsignConfigOk, textoParaPdfBase64, zapsignCriarDoc, onlyDigits,
} from "./zapsignClient.js";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
  });

const fmtBRL = (v) => `R$ ${Number(v || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`;

// Preenche {{variavel}} no texto do template. Aceita o superset usado tanto pelo
// TemplateEditor quanto pela página de assinatura.
function preencher(conteudo, vars) {
  if (!conteudo) return "";
  return conteudo.replace(/\{\{(\w+)\}\}/g, (_, k) => (vars[k] != null ? String(vars[k]) : `{{${k}}}`));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return json({});
  const base44 = createClientFromRequest(req);

  let body = {};
  try { body = await req.json(); } catch { return json({ error: "payload inválido" }, 400); }

  const { endereco, plano_info, dados, template_id, vendedor_id } = body || {};
  if (!endereco?.nome || !plano_info?.plano) {
    return json({ error: "Dados incompletos para assinatura." }, 400);
  }

  try {
    const plano = plano_info.plano;
    const total = plano_info.total ?? plano.preco_mensal ?? 0;
    const telefone = onlyDigits(endereco.telefone);

    // Resolve o nome do vendedor (link de indicação ?v=ID), se houver
    let vendedorNome = "";
    if (vendedor_id) {
      const u = await base44.asServiceRole.entities.User.filter({ id: vendedor_id }).catch(() => []);
      vendedorNome = u?.[0]?.full_name || "";
    }

    // 1) Lead
    const lead = await base44.asServiceRole.entities.Lead.create({
      nome: endereco.nome,
      cnpj_cpf: dados?.cpf || "",
      tipo_pessoa: onlyDigits(dados?.cpf).length > 11 ? "J" : "F",
      rg: dados?.rg || "",
      email: endereco.email || "",
      telefone: endereco.telefone || "",
      cep: dados?.end_instalacao_cep || endereco.cep || "",
      rua: dados?.end_instalacao_rua || endereco.endereco || "",
      numero: dados?.end_instalacao_numero || endereco.numero || "",
      complemento: dados?.end_instalacao_complemento || "",
      bairro: dados?.end_instalacao_bairro || endereco.bairro || "",
      cidade_nome: dados?.end_instalacao_cidade || endereco.cidade || "",
      uf: endereco.uf || "",
      canal_origem: "site",
      etapa_funil: "novo",
      data_entrada: new Date().toISOString(),
      observacao: `Assinatura online — ${plano.nome} (${plano.velocidade_mbps} Mbps). `
        + `Fidelidade: ${dados?.fidelidade || "12 meses"}, vencimento dia ${dados?.vencimento || "10"}.`
        + (vendedorNome ? ` Vendedor: ${vendedorNome}.` : ""),
    });

    // 2) Pedido
    const pedido = await base44.asServiceRole.entities.Pedido.create({
      lead_id: lead.id,
      lead_nome: endereco.nome,
      lead_cpf: dados?.cpf || "",
      plano_id: plano.id || "",
      plano_nome: plano.nome,
      valor: Number(total) || 0,
      status: "novo",
      canal_origem: "site",
      vendedor_id: vendedor_id || null,
      vendedor_nome: vendedorNome || null,
      observacao: "Pedido gerado pela assinatura online",
    });

    // 3) Sem ZapSign configurado -> segue para confirmação (sem assinatura digital)
    if (!zapsignConfigOk()) {
      return json({ done: true, lead_id: lead.id, pedido_id: pedido.id });
    }

    // 4) Monta o conteúdo do contrato (template selecionado ou texto padrão)
    const now = new Date();
    const vars = {
      cliente_nome: endereco.nome,
      cliente_cpf: dados?.cpf || "",
      cliente_rg: dados?.rg || "",
      cliente_email: endereco.email || "",
      cliente_telefone: endereco.telefone || "",
      cliente_endereco: `${dados?.end_instalacao_rua || endereco.endereco || ""}, ${dados?.end_instalacao_numero || endereco.numero || ""}`,
      cliente_numero: dados?.end_instalacao_numero || endereco.numero || "",
      cliente_complemento: dados?.end_instalacao_complemento || "",
      cliente_bairro: dados?.end_instalacao_bairro || endereco.bairro || "",
      cliente_cidade: dados?.end_instalacao_cidade || endereco.cidade || "",
      cliente_uf: endereco.uf || "",
      cliente_cep: dados?.end_instalacao_cep || endereco.cep || "",
      plano_nome: plano.nome,
      valor: fmtBRL(total),
      plano_valor: fmtBRL(total),
      plano_velocidade: `${plano.velocidade_mbps} Mbps`,
      fidelidade: dados?.fidelidade || "12 meses",
      vencimento_dia: dados?.vencimento || "10",
      vendedor_nome: vendedorNome || "",
      data_contrato: now.toLocaleDateString("pt-BR"),
      data_ativacao: new Date(Date.now() + 7 * 86400000).toLocaleDateString("pt-BR"),
      data_hoje: now.toLocaleDateString("pt-BR"),
      data_extenso: now.toLocaleDateString("pt-BR", { day: "numeric", month: "long", year: "numeric" }),
      cidade_contrato: dados?.end_instalacao_cidade || endereco.cidade || "",
    };

    let conteudo;
    if (template_id) {
      const tpl = (await base44.asServiceRole.entities.TemplateContrato.filter({ id: template_id }))[0];
      conteudo = tpl?.conteudo ? preencher(tpl.conteudo, vars)
        : `CONTRATO DE PRESTAÇÃO DE SERVIÇO\n\nCliente: ${endereco.nome}\nPlano: ${plano.nome} (${plano.velocidade_mbps} Mbps)\nValor: ${fmtBRL(total)}/mês`;
    } else {
      conteudo = `CONTRATO DE PRESTAÇÃO DE SERVIÇO DE INTERNET\n\n`
        + `Contratante: ${endereco.nome}\nCPF/CNPJ: ${dados?.cpf || "-"}\n`
        + `Endereço: ${vars.cliente_endereco} - ${vars.cliente_bairro}, ${vars.cliente_cidade}/${vars.cliente_uf}\n\n`
        + `Plano: ${plano.nome} (${plano.velocidade_mbps} Mbps)\nValor: ${fmtBRL(total)}/mês\n`
        + `Fidelidade: ${vars.fidelidade}\nVencimento: dia ${vars.vencimento_dia}\n\n`
        + `Data: ${vars.data_extenso}`;
    }

    // 5) PDF + envio ao ZapSign
    const base64_pdf = await textoParaPdfBase64(`Contrato — ${endereco.nome}`, conteudo);

    const signer = {
      name: endereco.nome,
      auth_mode: "assinaturaTela",
      send_automatic_email: Boolean(endereco.email),
      send_automatic_whatsapp: Boolean(telefone),
    };
    if (endereco.email) signer.email = endereco.email;
    if (telefone) { signer.phone_country = "55"; signer.phone_number = telefone.replace(/^55/, ""); }

    if (!endereco.email && !telefone) {
      // Sem canal de envio: cria contrato em rascunho e segue para confirmação
      return json({ done: true, lead_id: lead.id, pedido_id: pedido.id });
    }

    const doc = await zapsignCriarDoc({
      nome: `Contrato - ${endereco.nome}`,
      base64_pdf,
      external_id: pedido.id,
      signers: [signer],
    });

    const signUrl = doc?.signers?.[0]?.sign_url || "";
    const docToken = doc?.token || "";

    // 6) Grava Contrato + atualiza Pedido
    const contrato = await base44.asServiceRole.entities.Contrato.create({
      pedido_id: pedido.id,
      cliente_nome: endereco.nome,
      status: "enviado",
      link_assinatura: signUrl,
      zapsign_token: docToken,
      template_id: template_id || null,
      conteudo,
    }).catch(() => null);

    await base44.asServiceRole.entities.Pedido.update(pedido.id, {
      status: "contrato_pendente",
      link_assinatura: signUrl,
      zapsign_token: docToken,
      contrato_id: contrato?.id || null,
    });

    return json({ link_assinatura: signUrl, pedido_id: pedido.id, lead_id: lead.id });
  } catch (e) {
    return json({ error: e.message || "Erro ao processar assinatura" }, 500);
  }
});
